package com.sobatmental.web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
