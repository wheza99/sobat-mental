// Export pages
export '/pages/authentication/login/login_widget.dart' show LoginWidget;
export '/pages/main_page/home/home_widget.dart' show HomeWidget;
export '/pages/main_page/profile/profile_widget.dart' show ProfileWidget;
export '/pages/main_page/sobat/sobat_widget.dart' show SobatWidget;
export '/pages/main_page/chats/chats_widget.dart' show ChatsWidget;
export '/pages/journals/new_journal/new_journal_widget.dart'
    show NewJournalWidget;
export '/pages/journals/detail_journal/detail_journal_widget.dart'
    show DetailJournalWidget;
export '/pages/message/detail_chat/detail_chat_widget.dart'
    show DetailChatWidget;
export '/pages/professional/detail_professional/detail_professional_widget.dart'
    show DetailProfessionalWidget;
export '/pages/professional/my_professional/my_professional_widget.dart'
    show MyProfessionalWidget;
export '/pages/professional/post/post_widget.dart' show PostWidget;
export '/pages/professional/edit_professional/edit_professional_widget.dart'
    show EditProfessionalWidget;
export '/pages/payment/summary/summary_widget.dart' show SummaryWidget;
export '/pages/payment/pending/pending_widget.dart' show PendingWidget;
export '/pages/payment/receipt/receipt_widget.dart' show ReceiptWidget;
