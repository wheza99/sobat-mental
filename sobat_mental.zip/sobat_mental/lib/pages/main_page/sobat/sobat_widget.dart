import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:provider/provider.dart';
import 'sobat_model.dart';
export 'sobat_model.dart';

class SobatWidget extends StatefulWidget {
  const SobatWidget({super.key});

  @override
  State<SobatWidget> createState() => _SobatWidgetState();
}

class _SobatWidgetState extends State<SobatWidget> {
  late SobatModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SobatModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isiOS) {
      SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(
          statusBarBrightness: Theme.of(context).brightness,
          systemStatusBarContrastEnforced: true,
        ),
      );
    }

    return Title(
        title: 'sobat',
        color: FlutterFlowTheme.of(context).primary.withAlpha(0XFF),
        child: GestureDetector(
          onTap: () => _model.unfocusNode.canRequestFocus
              ? FocusScope.of(context).requestFocus(_model.unfocusNode)
              : FocusScope.of(context).unfocus(),
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            appBar: AppBar(
              backgroundColor: FlutterFlowTheme.of(context).primary,
              automaticallyImplyLeading: false,
              title: Text(
                'Sobat Curhat',
                style: FlutterFlowTheme.of(context).headlineMedium.override(
                      fontFamily: 'Urbanist',
                      color: Colors.white,
                      fontSize: 22.0,
                    ),
              ),
              actions: [],
              centerTitle: false,
              elevation: 2.0,
            ),
            body: SafeArea(
              top: true,
              child: Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: Container(
                  width: 500.0,
                  decoration: BoxDecoration(),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    child: PagedListView<DocumentSnapshot<Object?>?,
                        ProfessionalRecord>.separated(
                      pagingController: _model.setListViewController(
                        ProfessionalRecord.collection,
                      ),
                      padding: EdgeInsets.fromLTRB(
                        0,
                        24.0,
                        0,
                        48.0,
                      ),
                      reverse: false,
                      scrollDirection: Axis.vertical,
                      separatorBuilder: (_, __) => SizedBox(height: 16.0),
                      builderDelegate:
                          PagedChildBuilderDelegate<ProfessionalRecord>(
                        // Customize what your widget looks like when it's loading the first page.
                        firstPageProgressIndicatorBuilder: (_) => Center(
                          child: SizedBox(
                            width: 50.0,
                            height: 50.0,
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation<Color>(
                                FlutterFlowTheme.of(context).primary,
                              ),
                            ),
                          ),
                        ),
                        // Customize what your widget looks like when it's loading another page.
                        newPageProgressIndicatorBuilder: (_) => Center(
                          child: SizedBox(
                            width: 50.0,
                            height: 50.0,
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation<Color>(
                                FlutterFlowTheme.of(context).primary,
                              ),
                            ),
                          ),
                        ),

                        itemBuilder: (context, _, listViewIndex) {
                          final listViewProfessionalRecord = _model
                              .listViewPagingController!
                              .itemList![listViewIndex];
                          return InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              context.pushNamed(
                                'detailProfessional',
                                queryParameters: {
                                  'professional': serializeParam(
                                    listViewProfessionalRecord.reference,
                                    ParamType.DocumentReference,
                                  ),
                                }.withoutNulls,
                              );
                            },
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8.0),
                                  child: Image.network(
                                    valueOrDefault<String>(
                                      listViewProfessionalRecord.photo,
                                      'https://images.unsplash.com/photo-1529665253569-6d01c0eaf7b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NTYyMDF8MHwxfHNlYXJjaHwzfHxwcm9maWxlfGVufDB8fHx8MTcwMzcwNjM4NXww&ixlib=rb-4.0.3&q=80&w=1080',
                                    ),
                                    width: 50.0,
                                    height: 50.0,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Expanded(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Expanded(
                                            child: Text(
                                              listViewProfessionalRecord.name,
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Manrope',
                                                        fontSize: 16.0,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                      ),
                                            ),
                                          ),
                                          InkWell(
                                            splashColor: Colors.transparent,
                                            focusColor: Colors.transparent,
                                            hoverColor: Colors.transparent,
                                            highlightColor: Colors.transparent,
                                            onTap: () async {
                                              _model.queryChat =
                                                  await queryChatRecordOnce(
                                                queryBuilder: (chatRecord) =>
                                                    chatRecord
                                                        .where(
                                                          'user',
                                                          isEqualTo:
                                                              currentUserReference,
                                                        )
                                                        .where(
                                                          'professional',
                                                          isEqualTo:
                                                              listViewProfessionalRecord
                                                                  .reference,
                                                        ),
                                                singleRecord: true,
                                              ).then((s) => s.firstOrNull);
                                              if (_model.queryChat?.reference !=
                                                  null) {
                                                context.pushNamed(
                                                  'detailChat',
                                                  queryParameters: {
                                                    'chat': serializeParam(
                                                      _model
                                                          .queryChat?.reference,
                                                      ParamType
                                                          .DocumentReference,
                                                    ),
                                                    'professional':
                                                        serializeParam(
                                                      _model.queryChat
                                                          ?.professional,
                                                      ParamType
                                                          .DocumentReference,
                                                    ),
                                                  }.withoutNulls,
                                                );
                                              } else {
                                                var chatRecordReference =
                                                    ChatRecord.collection.doc();
                                                await chatRecordReference.set({
                                                  ...createChatRecordData(
                                                    user: currentUserReference,
                                                    userProfessional:
                                                        listViewProfessionalRecord
                                                            .user,
                                                    professional:
                                                        listViewProfessionalRecord
                                                            .reference,
                                                    lastMessage: 'Typing...',
                                                  ),
                                                  ...mapToFirestore(
                                                    {
                                                      'created_time': FieldValue
                                                          .serverTimestamp(),
                                                      'updated_time': FieldValue
                                                          .serverTimestamp(),
                                                    },
                                                  ),
                                                });
                                                _model.createChat = ChatRecord
                                                    .getDocumentFromData({
                                                  ...createChatRecordData(
                                                    user: currentUserReference,
                                                    userProfessional:
                                                        listViewProfessionalRecord
                                                            .user,
                                                    professional:
                                                        listViewProfessionalRecord
                                                            .reference,
                                                    lastMessage: 'Typing...',
                                                  ),
                                                  ...mapToFirestore(
                                                    {
                                                      'created_time':
                                                          DateTime.now(),
                                                      'updated_time':
                                                          DateTime.now(),
                                                    },
                                                  ),
                                                }, chatRecordReference);

                                                context.pushNamed(
                                                  'detailChat',
                                                  queryParameters: {
                                                    'chat': serializeParam(
                                                      _model.createChat
                                                          ?.reference,
                                                      ParamType
                                                          .DocumentReference,
                                                    ),
                                                    'professional':
                                                        serializeParam(
                                                      _model.createChat
                                                          ?.professional,
                                                      ParamType
                                                          .DocumentReference,
                                                    ),
                                                  }.withoutNulls,
                                                );
                                              }

                                              setState(() {});
                                            },
                                            child: Icon(
                                              Icons.mark_chat_unread,
                                              color: listViewProfessionalRecord
                                                      .available
                                                  ? FlutterFlowTheme.of(context)
                                                      .success
                                                  : FlutterFlowTheme.of(context)
                                                      .secondaryText,
                                              size: 24.0,
                                            ),
                                          ),
                                        ].divide(SizedBox(width: 8.0)),
                                      ),
                                      Text(
                                        listViewProfessionalRecord.type,
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium,
                                      ),
                                      Divider(
                                        thickness: 1.0,
                                        color: FlutterFlowTheme.of(context)
                                            .primaryText,
                                      ),
                                    ].divide(SizedBox(height: 4.0)),
                                  ),
                                ),
                              ].divide(SizedBox(width: 8.0)),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ));
  }
}
