import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCoT23Eq3YzIzvZ5ddvoI6vRW-sRHLopes",
            authDomain: "sobat-mental.firebaseapp.com",
            projectId: "sobat-mental",
            storageBucket: "sobat-mental.appspot.com",
            messagingSenderId: "99907327881",
            appId: "1:99907327881:web:676edcd09bccce29607358"));
  } else {
    await Firebase.initializeApp();
  }
}
