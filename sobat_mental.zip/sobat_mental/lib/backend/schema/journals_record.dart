import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class JournalsRecord extends FirestoreRecord {
  JournalsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "updated_time" field.
  DateTime? _updatedTime;
  DateTime? get updatedTime => _updatedTime;
  bool hasUpdatedTime() => _updatedTime != null;

  // "feelings" field.
  int? _feelings;
  int get feelings => _feelings ?? 0;
  bool hasFeelings() => _feelings != null;

  // "journals" field.
  String? _journals;
  String get journals => _journals ?? '';
  bool hasJournals() => _journals != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _createdTime = snapshotData['created_time'] as DateTime?;
    _updatedTime = snapshotData['updated_time'] as DateTime?;
    _feelings = castToType<int>(snapshotData['feelings']);
    _journals = snapshotData['journals'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('journals')
          : FirebaseFirestore.instance.collectionGroup('journals');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('journals').doc(id);

  static Stream<JournalsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => JournalsRecord.fromSnapshot(s));

  static Future<JournalsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => JournalsRecord.fromSnapshot(s));

  static JournalsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      JournalsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static JournalsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      JournalsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'JournalsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is JournalsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createJournalsRecordData({
  DateTime? createdTime,
  DateTime? updatedTime,
  int? feelings,
  String? journals,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'created_time': createdTime,
      'updated_time': updatedTime,
      'feelings': feelings,
      'journals': journals,
    }.withoutNulls,
  );

  return firestoreData;
}

class JournalsRecordDocumentEquality implements Equality<JournalsRecord> {
  const JournalsRecordDocumentEquality();

  @override
  bool equals(JournalsRecord? e1, JournalsRecord? e2) {
    return e1?.createdTime == e2?.createdTime &&
        e1?.updatedTime == e2?.updatedTime &&
        e1?.feelings == e2?.feelings &&
        e1?.journals == e2?.journals;
  }

  @override
  int hash(JournalsRecord? e) => const ListEquality()
      .hash([e?.createdTime, e?.updatedTime, e?.feelings, e?.journals]);

  @override
  bool isValidKey(Object? o) => o is JournalsRecord;
}
