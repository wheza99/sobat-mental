import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChatItemRecord extends FirestoreRecord {
  ChatItemRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "updated_time" field.
  DateTime? _updatedTime;
  DateTime? get updatedTime => _updatedTime;
  bool hasUpdatedTime() => _updatedTime != null;

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  bool hasMessage() => _message != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _createdTime = snapshotData['created_time'] as DateTime?;
    _updatedTime = snapshotData['updated_time'] as DateTime?;
    _user = snapshotData['user'] as DocumentReference?;
    _message = snapshotData['message'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('chat_item')
          : FirebaseFirestore.instance.collectionGroup('chat_item');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('chat_item').doc(id);

  static Stream<ChatItemRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ChatItemRecord.fromSnapshot(s));

  static Future<ChatItemRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ChatItemRecord.fromSnapshot(s));

  static ChatItemRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ChatItemRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ChatItemRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ChatItemRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ChatItemRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ChatItemRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createChatItemRecordData({
  DateTime? createdTime,
  DateTime? updatedTime,
  DocumentReference? user,
  String? message,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'created_time': createdTime,
      'updated_time': updatedTime,
      'user': user,
      'message': message,
    }.withoutNulls,
  );

  return firestoreData;
}

class ChatItemRecordDocumentEquality implements Equality<ChatItemRecord> {
  const ChatItemRecordDocumentEquality();

  @override
  bool equals(ChatItemRecord? e1, ChatItemRecord? e2) {
    return e1?.createdTime == e2?.createdTime &&
        e1?.updatedTime == e2?.updatedTime &&
        e1?.user == e2?.user &&
        e1?.message == e2?.message;
  }

  @override
  int hash(ChatItemRecord? e) => const ListEquality()
      .hash([e?.createdTime, e?.updatedTime, e?.user, e?.message]);

  @override
  bool isValidKey(Object? o) => o is ChatItemRecord;
}
