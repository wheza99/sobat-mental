import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ProfessionalRecord extends FirestoreRecord {
  ProfessionalRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "updated_time" field.
  DateTime? _updatedTime;
  DateTime? get updatedTime => _updatedTime;
  bool hasUpdatedTime() => _updatedTime != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  bool hasType() => _type != null;

  // "photo" field.
  String? _photo;
  String get photo => _photo ?? '';
  bool hasPhoto() => _photo != null;

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  // "followers" field.
  List<DocumentReference>? _followers;
  List<DocumentReference> get followers => _followers ?? const [];
  bool hasFollowers() => _followers != null;

  // "available" field.
  bool? _available;
  bool get available => _available ?? false;
  bool hasAvailable() => _available != null;

  // "price" field.
  int? _price;
  int get price => _price ?? 0;
  bool hasPrice() => _price != null;

  // "duration" field.
  int? _duration;
  int get duration => _duration ?? 0;
  bool hasDuration() => _duration != null;

  void _initializeFields() {
    _createdTime = snapshotData['created_time'] as DateTime?;
    _updatedTime = snapshotData['updated_time'] as DateTime?;
    _name = snapshotData['name'] as String?;
    _type = snapshotData['type'] as String?;
    _photo = snapshotData['photo'] as String?;
    _user = snapshotData['user'] as DocumentReference?;
    _followers = getDataList(snapshotData['followers']);
    _available = snapshotData['available'] as bool?;
    _price = castToType<int>(snapshotData['price']);
    _duration = castToType<int>(snapshotData['duration']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('professional');

  static Stream<ProfessionalRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ProfessionalRecord.fromSnapshot(s));

  static Future<ProfessionalRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ProfessionalRecord.fromSnapshot(s));

  static ProfessionalRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ProfessionalRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ProfessionalRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ProfessionalRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ProfessionalRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ProfessionalRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createProfessionalRecordData({
  DateTime? createdTime,
  DateTime? updatedTime,
  String? name,
  String? type,
  String? photo,
  DocumentReference? user,
  bool? available,
  int? price,
  int? duration,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'created_time': createdTime,
      'updated_time': updatedTime,
      'name': name,
      'type': type,
      'photo': photo,
      'user': user,
      'available': available,
      'price': price,
      'duration': duration,
    }.withoutNulls,
  );

  return firestoreData;
}

class ProfessionalRecordDocumentEquality
    implements Equality<ProfessionalRecord> {
  const ProfessionalRecordDocumentEquality();

  @override
  bool equals(ProfessionalRecord? e1, ProfessionalRecord? e2) {
    const listEquality = ListEquality();
    return e1?.createdTime == e2?.createdTime &&
        e1?.updatedTime == e2?.updatedTime &&
        e1?.name == e2?.name &&
        e1?.type == e2?.type &&
        e1?.photo == e2?.photo &&
        e1?.user == e2?.user &&
        listEquality.equals(e1?.followers, e2?.followers) &&
        e1?.available == e2?.available &&
        e1?.price == e2?.price &&
        e1?.duration == e2?.duration;
  }

  @override
  int hash(ProfessionalRecord? e) => const ListEquality().hash([
        e?.createdTime,
        e?.updatedTime,
        e?.name,
        e?.type,
        e?.photo,
        e?.user,
        e?.followers,
        e?.available,
        e?.price,
        e?.duration
      ]);

  @override
  bool isValidKey(Object? o) => o is ProfessionalRecord;
}
