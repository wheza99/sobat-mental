import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChatRecord extends FirestoreRecord {
  ChatRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "updated_time" field.
  DateTime? _updatedTime;
  DateTime? get updatedTime => _updatedTime;
  bool hasUpdatedTime() => _updatedTime != null;

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  // "user_professional" field.
  DocumentReference? _userProfessional;
  DocumentReference? get userProfessional => _userProfessional;
  bool hasUserProfessional() => _userProfessional != null;

  // "professional" field.
  DocumentReference? _professional;
  DocumentReference? get professional => _professional;
  bool hasProfessional() => _professional != null;

  // "last_message" field.
  String? _lastMessage;
  String get lastMessage => _lastMessage ?? '';
  bool hasLastMessage() => _lastMessage != null;

  // "last_seen_user" field.
  DateTime? _lastSeenUser;
  DateTime? get lastSeenUser => _lastSeenUser;
  bool hasLastSeenUser() => _lastSeenUser != null;

  // "last_seen_user_professional" field.
  DateTime? _lastSeenUserProfessional;
  DateTime? get lastSeenUserProfessional => _lastSeenUserProfessional;
  bool hasLastSeenUserProfessional() => _lastSeenUserProfessional != null;

  void _initializeFields() {
    _createdTime = snapshotData['created_time'] as DateTime?;
    _updatedTime = snapshotData['updated_time'] as DateTime?;
    _user = snapshotData['user'] as DocumentReference?;
    _userProfessional = snapshotData['user_professional'] as DocumentReference?;
    _professional = snapshotData['professional'] as DocumentReference?;
    _lastMessage = snapshotData['last_message'] as String?;
    _lastSeenUser = snapshotData['last_seen_user'] as DateTime?;
    _lastSeenUserProfessional =
        snapshotData['last_seen_user_professional'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('chat');

  static Stream<ChatRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ChatRecord.fromSnapshot(s));

  static Future<ChatRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ChatRecord.fromSnapshot(s));

  static ChatRecord fromSnapshot(DocumentSnapshot snapshot) => ChatRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ChatRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ChatRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ChatRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ChatRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createChatRecordData({
  DateTime? createdTime,
  DateTime? updatedTime,
  DocumentReference? user,
  DocumentReference? userProfessional,
  DocumentReference? professional,
  String? lastMessage,
  DateTime? lastSeenUser,
  DateTime? lastSeenUserProfessional,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'created_time': createdTime,
      'updated_time': updatedTime,
      'user': user,
      'user_professional': userProfessional,
      'professional': professional,
      'last_message': lastMessage,
      'last_seen_user': lastSeenUser,
      'last_seen_user_professional': lastSeenUserProfessional,
    }.withoutNulls,
  );

  return firestoreData;
}

class ChatRecordDocumentEquality implements Equality<ChatRecord> {
  const ChatRecordDocumentEquality();

  @override
  bool equals(ChatRecord? e1, ChatRecord? e2) {
    return e1?.createdTime == e2?.createdTime &&
        e1?.updatedTime == e2?.updatedTime &&
        e1?.user == e2?.user &&
        e1?.userProfessional == e2?.userProfessional &&
        e1?.professional == e2?.professional &&
        e1?.lastMessage == e2?.lastMessage &&
        e1?.lastSeenUser == e2?.lastSeenUser &&
        e1?.lastSeenUserProfessional == e2?.lastSeenUserProfessional;
  }

  @override
  int hash(ChatRecord? e) => const ListEquality().hash([
        e?.createdTime,
        e?.updatedTime,
        e?.user,
        e?.userProfessional,
        e?.professional,
        e?.lastMessage,
        e?.lastSeenUser,
        e?.lastSeenUserProfessional
      ]);

  @override
  bool isValidKey(Object? o) => o is ChatRecord;
}
