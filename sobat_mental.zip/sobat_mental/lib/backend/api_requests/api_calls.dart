import 'dart:convert';
import 'dart:typed_data';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class XenditPostCall {
  static Future<ApiCallResponse> call({
    String? aPIKey = '',
    String? docId = '',
    int? amount,
    String? desc = '',
    String? name = '',
    String? email = '',
    String? phone = '',
    int? itemPrice,
  }) async {
    final ffApiRequestBody = '''
{
  "id": "${docId}",
  "amount": ${amount},
  "desc": "${desc}",
  "name": "${name}",
  "email": "${email}",
  "phone": "${phone}",
  "itemPrice": ${itemPrice}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Xendit Post',
      apiUrl: 'https://x8ki-letl-twmt.n7.xano.io/api:v9e6diqM/XenditPost',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static String? invoiceUrl(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.response.result.invoice_url''',
      ));
  static String? id(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.response.result.id''',
      ));
}

class XenditGetCall {
  static Future<ApiCallResponse> call({
    String? invoiceId = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Xendit Get',
      apiUrl: 'https://x8ki-letl-twmt.n7.xano.io/api:v9e6diqM/XenditGet',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'url': invoiceId,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static String? status(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.response.result.status''',
      ));
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list);
  } catch (_) {
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar);
  } catch (_) {
    return isList ? '[]' : '{}';
  }
}
